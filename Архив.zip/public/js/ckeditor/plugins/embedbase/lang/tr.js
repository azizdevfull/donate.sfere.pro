/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'tr', {
	pathName: 'medya nesnesi',
	title: 'Gömülmüş Medya',
	button: 'Gömülü Medya Ekle',
	unsupportedUrlGiven: 'Belirtmiş olduğunuz URL desteklenmiyor.',
	unsupportedUrl: 'Belirttiğiniz URL {url} gömülü medya tarafından desteklenmiyor.',
	fetchingFailedGiven: 'Vermiş olduğunuz URL\'nin içeriği alınamadı.',
	fetchingFailed: '{url} içeriği alınamadı.',
	fetchingOne: 'oEmbed cevabı alınıyor...',
	fetchingMany: 'oEmbed cevabı alınıyor, {current} / {max} tamamlandı...'
} );
